from task_tracker.task_tracker import Task
import json

class TaskManager:
    __file_path = "tasks.json"

    class Options:
        done = "done"
        todo = "todo"
        in_progress = "in-progress"

    def __init__(self):
        self._tasks = {} 
        self.load_tasks()
        

    def load_tasks(self):
        """Load tasks from JSON file into self._tasks"""
        try:
            with open(TaskManager.__file_path, "r") as file:
                task_list = json.load(file)
                for task_id, task_data in task_list.items():
                    task_obj = Task.from_dict(task_data)
                    self._tasks[int(task_id)] = task_obj
        except FileNotFoundError:
            self._tasks = {}
        except json.JSONDecodeError:
            self._tasks = {} 

    def task_id_generate(self):
        """
        Generates a unique task ID based on existing tasks.
        """

        if not self._tasks:
            return 1
        return max(self._tasks.keys()) + 1
        


    def add_task(self, description: str):
        """
        Create a new Task with a unique ID and store it.
        """
        new_id = self.task_id_generate()
        task = Task(task_id=new_id, description=description)
        self._tasks[new_id] = task
        self.save_tasks()
        return task

    def update_task(self, task_id: int, description=None, status=None):
        """
        Update an existing task and persist changes.
        """
        task = self._tasks.get(task_id)

        if not task:
            raise ValueError(f"Task with id {task_id} does not exist")

        task.update(description=description, status=status)

        self.save_tasks()

        return task


    def delete_task(self, task_id: int):
        """
        Delete a task by ID and persist the change.
        """

        if task_id not in self._tasks:
            raise ValueError(f"Task with id {task_id} not found")
        del self._tasks[task_id]

        self.save_tasks()


    def list_tasks(self, status=None):
        """Return tasks, optionally filtered by status"""

        if not self._tasks:
            return []
        if status is None:
            return list(self._tasks.values()) 
        
        return [
            task for task in self._tasks.values()
            if task.status == status
        ]
    
        

    def save_tasks(self):
        """Save tasks to JSON file."""

        data = {}

        for task_id, task in self._tasks.items():
            data[task_id] = task.to_dict()

        with open(self.__file_path, "w") as file:
            json.dump(data, file)

