# Task Tracker CLI  Project

Task Tracker CLI is a command line interface built in python for managing tasks via the terminal. Arguments such as "add" for adding tasks, "list" for listing tasks optionally filtered by status, "update" for updating an exisiting task based and "delete" for deleting a task by ID. 


## Installation


